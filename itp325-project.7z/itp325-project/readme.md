# Rubber Ducky Readme
### Tyler Chrystal
### ITP 325

**Difficulties with the Project**
1. Couldn't figure out how to turn root directory into a file that could be encrypted with gpg.
2. Also unsure of how to insert meterpreter backdoor.
3. Delays were difficult to optimize.
4. Not sure how to write an if statement so that it goes to different extension link depending on default browser.
5. 

